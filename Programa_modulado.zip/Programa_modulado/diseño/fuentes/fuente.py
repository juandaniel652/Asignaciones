from tkinter import font

class Fuentes :
    
    def __init__(self):
        self.fuente_titulo = font.Font(size=15, weight="bold")
        self.fuente_listbox = font.Font(size=10, slant="italic")