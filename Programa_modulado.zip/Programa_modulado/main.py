from diseño.interfaz import Interfaz


if __name__ == "__main__":
    app = Interfaz()
    app.iniciar_programa()